import java.util.Random;
//import java.util.Scanner;
public class Die {
	private int value;
	  private Random rand;
	  
	  public Die() {
	    value = 0;
	    rand = new Random();
	  }
	 
	  public void roll() {
	    value = 1 + rand.nextInt(6);
	  }	 
	  public int get() {
	    return (value);
	  }
	  
	//recursive function
	  public int score(int n) {
			int sum = 0;
  	  if(n < 0) 
			return 0;
			else
  	  sum= sum +score(n-1);
			return sum;
	}
}
