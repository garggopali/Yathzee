import java.util.Scanner;
public class ScoreBoard {	
    // sorting function
	public void scoreSorting(int s[],int key) {
    	for (int i = 1; i < s.length; i++) {
            int index = s[i];
            int j = i;
            while ( (j > 0) && ( s [j-1] > index ) ) {
                s [j] = s [j-1];
                j--;
            }
            s[j] = index;
            int p=s[j];
            // Print array
            for (j = 0; j < s.length; j++) {
                System.out.print(s[j] + ", ");
           }
            System.out.println("\n");
        }
    }
	// Searching function
    public void scoreSearch(int[] a, int key) {
    	int first  = 0;
        int last   = a.length - 1;
        int mid = (first + last)/2;
     
        while( first <= last )
        {
          if ( a[mid] < key )
            first = mid + 1;    
          else if ( a[mid] == key ) 
          {
            System.out.println(key + " is found at location " + (mid+1) + " in the sorted list.");
            break;
          }
          else
             last = mid - 1;
          mid = (first + last)/2;
       }
       if ( first > last )
          System.out.println(key + " is not present in the list.\n");
    }
}