import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class YahtzeeMain1 {
	public static final String URL = "jdbc:sqlserver://localhost:1433;DatabaseName=ECYatzy";
	public static Connection connection;
	public static boolean Connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(URL, "sa", "gopali");
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public static boolean Disconnect() {
		try {
			connection.close();
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
	
	public static int ExecuteNonQuery(PreparedStatement prepareStatement){
		try {
			return prepareStatement.executeUpdate();
		} catch (Exception ex) {
			return -1;
		}
	}

	public static ResultSet ExecuteQuery(PreparedStatement sql) {
		try {
			return sql.executeQuery();
		} catch (SQLException ex) {
			return null;
		}
	}

	public static void PrintResult(ResultSet result) {
		try {
			System.out.println("------------------------------------------------------------------");
			System.out.println("\tHighest final score of the game from the ECYatzy DataBase are :");
			System.out.println("******************************************************************");
			System.out.println("Player ID \t Player Name \t Play Date \t Game Score ");
			System.out.println("******************************************************************");
			while (result.next()) {
				System.out.println(result.getString("PlayerID") + "\t\t" + result.getString("PlayerName")+"\t" +
			result.getString("PlayDate")+"\t" +  result.getString("GameScore"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void PrintResult1(ResultSet result) {
		try {
			System.out.println("------------------------------------------------------------------");
			System.out.println("\tHistory of a player from the ECYatzy DataBase are :");
			System.out.println("******************************************************************");
			System.out.println("Player ID \t Player Name \t Game Score \t Play Date ");
			System.out.println("******************************************************************");
			while (result.next()) {
				System.out.println(result.getString("PlayerID") + "\t\t" + result.getString("PlayerName")+"\t\t" +
			result.getString("GameScore")+"\t\t" +  result.getString("PlayDate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void PrintResult2(ResultSet result) {
		try {
			System.out.println("------------------------------------------------------------------");
			System.out.println("\t Details of Winner's in the game is: ");
			System.out.println("******************************************************************");
			System.out.println("ID \t Winner's Name \t Winner's Score \t Party ended Date :");
			System.out.println("******************************************************************");
			while (result.next()) {
				System.out.println(result.getString("PlayerID") + "\t\t" + result.getString("PlayerName") + "\t"+ result.getString("GameScore")+ "\t\t" + result.getString("PlayDate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void PrintResult3(ResultSet result) {
		try {
			System.out.println("------------------------------------------------------------------");
			System.out.println("\t Details of losser's in the game : ");
			System.out.println("******************************************************************");
			System.out.println("ID \t Losser's Name \t Losser's Score :");
			System.out.println("******************************************************************");
			while (result.next()) {
				System.out.println(result.getString("PlayerID") + "\t\t" + result.getString("PlayerName") + "\t"+ result.getString("GameScore"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void PrintResult4(ResultSet result) {
		try {
			System.out.println("------------------------------------------------------------------");
			System.out.println("\t Details of Round in the game are: ");
			System.out.println("*****************************************************************************************");
			System.out.println("Round_No Player_ID  Dice_1  Dice_2  Dice_3  Dice_4  Dice_5      Type          Round_Point:");
			System.out.println("*****************************************************************************************");
			while (result.next()) {
				System.out.println(result.getString("RoundNo") + "\t"+result.getString("PlayerID")+"\t\t" +  result.getString("Dice1")+ "\t"+ result.getString("Dice2")+ "\t"+ result.getString("Dice3")+ "\t"+ result.getString("Dice4")+ "\t"+ result.getString("Dice5")
						+ "\t"+ result.getString("TypeID")+"\t"+result.getString("RoundPoints"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws SQLException {
		boolean connectionOk = YahtzeeMain1.Connect();
		if (connectionOk) {
			Scanner scan = new Scanner(System.in);
			HigestFinalScore();
			PlayerHistory(scan);
			WinnersDetails();
			LossersDetails();
			RoundDetails(scan);	
			//RollAndInsert();
		} else {
			System.out.println("Could not connect to server!");
		}	
	}

	public static void RollAndInsert(){
		//Roll dice one time and get random values:
		 try {
		int[] dice=new int[] { 0, 0, 0, 0, 0 };  //declaring an int array representing the 5 dice 
		int x;
		Die die = new Die();
	      for (x = 0; x < 5; x++) {
	      die.roll();
	      dice[x] = die.get();// sets the dice values
	      System.out.println("Dice "+x+ " is : "+dice[x]);
	    }
	     //Re-roll dice
	      for(int i=1;i<3;i++){
	      System.out.println("How many dice do you want to reroll in ? (1-4)");
	      Scanner scan = new Scanner(System.in);
		  int n=scan.nextInt();
	      int[] rroll = new int[n];
	      if(n>0){
	    	  for (int y = 0; y < n; y++) {
	    		  System.out.println("Which one ? (0-4)");
	    	   	int b=scan.nextInt();
	    	   //	die.roll();
	    	   	//rroll[b]=die.get();
	              rroll[y] = b;
	              System.out.println (rroll[y]);
	           }
	      for (int w = 0; w < n; w++) {
	    	    if (rroll[w] == 0) {
	    	      die.roll();
	    	      dice[1] = die.get();
	    	    }
	    	    if (rroll[w] == 1) {
	    	      die.roll();
	    	      dice[2] = die.get();
	    	    }
	    	    if (rroll[w] == 3) {
	    	      die.roll();
	    	      dice[3] = die.get();
	    	    }
	    	    if (rroll[w] == 4) {
	    	      die.roll();
	    	      dice[4] = die.get();
	    	    }
	    	    if (rroll[w] == 5) {
	    	      die.roll();
	    	      dice[5] = die.get();
	    	    }
	      System.out.println("Dice "+w+ " is : "+dice[w]);
  	 } 
	      }
	      }
   //   for( int j = 1; j<=5;j++)
    //{
   	  //System.out.println("updated dices are : " + dice[j]);
			String sql = "INSERT INTO dbo.[DiceRoll] VALUES(1,3,4,2,3,4,'ss')";
			PreparedStatement statement = YahtzeeMain1.connection.prepareStatement(sql);		
			int result = YahtzeeMain1.ExecuteNonQuery(statement);
			System.out.println("Number of rows changed: " + result);
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	
public static void WinnersDetails() {
	try {
		String sql = "SELECT top 1 * FROM [Player] inner join Game on Player.PlayerID=Game.PlayerID order by GameScore desc";
		PreparedStatement statement = YahtzeeMain1.connection.prepareStatement(sql);
		ResultSet result = YahtzeeMain1.ExecuteQuery(statement);
		PrintResult2(result);
	} catch (Exception e) {
		e.printStackTrace();
	}
}

public static void LossersDetails() {
	try {
		String sql = "SELECT top 1 * FROM [Player] inner join Game on Player.PlayerID=Game.PlayerID order by GameScore";
		PreparedStatement statement = YahtzeeMain1.connection.prepareStatement(sql);
		ResultSet result = YahtzeeMain1.ExecuteQuery(statement);
		PrintResult3(result);
	} catch (Exception e) {
		e.printStackTrace();
	}
}

public static void HigestFinalScore() {
	try{
		String sql = "SELECT top 3 * FROM [Player] inner join [Game] on Game.PlayerID= Player.PlayerID order by GameScore desc";
		PreparedStatement statement = YahtzeeMain1.connection.prepareStatement(sql);
		ResultSet result = YahtzeeMain1.ExecuteQuery(statement);
		PrintResult(result);
	}catch (Exception e) {
		e.printStackTrace();
	}
}

public static void PlayerHistory(Scanner scan) {
	try {
		System.out.println("Enter Player Name from AA, BB, CC, DD: ");
		//Scanner scanIn = new Scanner(System.in);    
		String input = scan.nextLine();
		//scan.close();
		String sql = "SELECT * FROM [Player] inner join Game on Game.PlayerID=Player.PlayerID WHERE [PlayerName]=?";
		PreparedStatement statement = YahtzeeMain1.connection.prepareStatement(sql);
		statement.setString(1, input);
		ResultSet result = YahtzeeMain1.ExecuteQuery(statement);
		PrintResult1(result);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public static void RoundDetails(Scanner scan) {
	try {
		System.out.println("Enter Player Id from 11, 12, 13, 14: ");
		//Scanner scan = new Scanner(System.in);
		int input1 = scan.nextInt();
		//scan.close();
		String sql = "SELECT * FROM [Round] WHERE [PlayerID]=?";
		PreparedStatement statement = YahtzeeMain1.connection.prepareStatement(sql);
		statement.setInt(1,input1);
		ResultSet result = YahtzeeMain1.ExecuteQuery(statement);
		PrintResult4(result);
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
}